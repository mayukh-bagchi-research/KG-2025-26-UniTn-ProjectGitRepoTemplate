# ProjectRepositoryTemplate
This is a template fort all the KGE projects repository. In general the structure of this repository has to be applied to every iTelos project.
