In this directory you have store all the material considered and created for the data definition phase
