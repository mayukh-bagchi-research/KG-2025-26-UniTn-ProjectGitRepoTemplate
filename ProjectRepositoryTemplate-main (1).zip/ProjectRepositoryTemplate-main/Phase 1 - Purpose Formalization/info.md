In this directory you have store all the material considered for the purpose formalization phase
