This directory stores allt he code libraries developded and/or adopted to collect project resources. 
