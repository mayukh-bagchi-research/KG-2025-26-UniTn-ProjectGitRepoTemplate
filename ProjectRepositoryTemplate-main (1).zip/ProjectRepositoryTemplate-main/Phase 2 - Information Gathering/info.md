In this directory you have store all the material (resources included) considered for the information gathering phase
