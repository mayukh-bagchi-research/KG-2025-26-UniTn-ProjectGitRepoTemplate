This directory contains all the material produced during the evaluation of the project results.
