This directory stores the project report document and the final presentation (slides) of the project
