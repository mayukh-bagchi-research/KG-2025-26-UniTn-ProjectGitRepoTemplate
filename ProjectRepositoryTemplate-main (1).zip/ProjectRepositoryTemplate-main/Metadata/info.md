This directory has to collect the definiton of all the metadata defined for the different inputs and outputs along all the project phases.
The metadata has to be proprly organized based on the type of resource considered.
From this folder the metadata will be extracted, in order to share the result of the project on the dedicated data catalogs.
